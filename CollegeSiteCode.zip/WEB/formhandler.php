<?php
$name = $_POST['name'];
$vistor_email=$_POST['email'];
$subject =$_POST['subject'];
$subject=$_POST['message'];
$email_from='EESWARANPANDI84@GMAIL.COM';
$email_subject ='new form submission';
$email_body="user name :$name.\n".
             "user name :$visitor_email.\n".
             "user name :$subject.\n".
             "user name :$message.\n";
             $to ='eeswaranpandi86@gmail.com';

             $headers ="from: $email_from \r\n";
             $headers="from:$visitor_email \r\n";


             mail(($to,$email_subject,$email_body,$headers));
             header("location: contact.html");






?>



